ASSET UNDANGAN FENAN & RENSA
Foto pasangan sudah disertakan.
Untuk musik, masukkan file MP3 instrumental ke folder assets dengan nama musik.mp3.
Nama pemilik rekening belum dikonfirmasi. Isi CONFIG.accountOwner di script.js setelah nama pemilik rekening diketahui.
Nomor WhatsApp RSVP dan nomor rekening telah dimasukkan sesuai informasi yang diberikan.
